export class Users{
    usersId:string;
    firstName:string;
    lastName:string;
    employeeId:string;
}