export class ParentTask {
    parentTaskId:number;
    parentTask:string;
}