export class Project{
    projectId:string;
    projectName:string;
    priorityFrom:number;
	priorityTo:number;
    projectStartDate:string;
    projectEndDate:string;
    firstName:string;
    projectStatus:string;

}